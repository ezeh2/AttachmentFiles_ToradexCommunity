﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using HttpListenerExample;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            var x = new HTTPKServer();
            x.ProcessRequest = ProcessMessage;
            x.Start(64001);
            Console.ReadLine();
            x.Stop();
        }

        static HTTPKServer.Response ProcessMessage(String request)
        {
            Debug.WriteLine(string.Format("Request:{0}", request));
            Console.Out.WriteLine(string.Format("Request:{0}", request));
            var response = new HTTPKServer.Response();

            if (request.StartsWith("POST"))
            {
                HandlePostRequest(request, response);
            }
            else if (request.StartsWith("GET"))
            {
                HandleGetRequest(request, response);
            }
            return response;
        }

        static HTTPKServer.Response HandlePostRequest(String request, HTTPKServer.Response response)
        {
            var responseText = "this is data !!! and even more data";
            var responseData = Encoding.UTF8.GetBytes(responseText);
            response.Data = responseData;
            return response;
        }

        static HTTPKServer.Response HandleGetRequest(String request, HTTPKServer.Response response)
        {
            var responseText = "Hello!";
            var responseData = Encoding.UTF8.GetBytes(responseText);
            response.Data = responseData;
            return response;
        }
    }
}
