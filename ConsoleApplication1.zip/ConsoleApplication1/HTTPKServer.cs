﻿using System;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace HttpListenerExample
{
    class HTTPKServer
    {
        Thread _serverThread = null;
        Socket _listener;

        public class Response
        {
            public Response()
            {
                MimeType = "text/plain";
            }

            public byte[] Data { get; set; }
            public String MimeType { get; set; }
        }

        public delegate Response ProcessRequestDelegate(String request);
        public ProcessRequestDelegate ProcessRequest;

        public void Start(int port)
        {
            if (_serverThread == null)
            {
                IPAddress ipAddress = new IPAddress(0);

                _listener = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

                // in NET 6.0 verfuegbar, aber nicht in .NET 4.8:
                // TcpKeepAliveInterval
                // TcpKeepAliveRetryCount
                // TcpKeepAliveTime

                // this work in .NET 4.8, but not Compact FWK 3.9
                // 128
                // object ipTimeToLive = _listener.GetSocketOption(SocketOptionLevel.IP, SocketOptionName.IpTimeToLive);
                // alles 0 and false
                /*
                object linger = _listener.GetSocketOption(SocketOptionLevel.Socket, SocketOptionName.Linger);
                object keepAlive = _listener.GetSocketOption(SocketOptionLevel.Socket, SocketOptionName.KeepAlive);
                object sendTimeout = _listener.GetSocketOption(SocketOptionLevel.Socket, SocketOptionName.SendTimeout);
                object receiveTimeout = _listener.GetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReceiveTimeout);
                object noDelay = _listener.GetSocketOption(SocketOptionLevel.Tcp, SocketOptionName.NoDelay);
                */

                _listener.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.Linger, new LingerOption(false, 0));
                _listener.Bind(new IPEndPoint(IPAddress.Any, port));
                _listener.Listen(256);

                //_listener = new TcpListener(ipAddress, port);
                _serverThread = new Thread(ServerHandler);
                _serverThread.Start();
            }
        }

        public void Stop()
        {
            if (_serverThread != null)
            {
                _serverThread.Abort();
                _serverThread = null;
            }
        }

        String ReadRequest(NetworkStream stream)
        {
            MemoryStream contents = new MemoryStream();
            var buffer = new byte[2048];
            do
            {
                var size = stream.Read(buffer, 0, buffer.Length);
                if (size == 0)
                {
                    return null;
                }
                contents.Write(buffer, 0, size);
            } while (stream.DataAvailable);
            var data = contents.ToArray();
            var retVal = Encoding.UTF8.GetString(data, 0, data.Length);
            return retVal;
        }

        void ServerHandler()
        {
            while (true)
            {
                var client = _listener.Accept();
                var stream = new NetworkStream(client, FileAccess.ReadWrite, false);

                try
                {
                    var request = ReadRequest(stream);

                    if (ProcessRequest != null)
                    {
                        var response = ProcessRequest(request);
                        var responseBuilder = new StringBuilder();
                        responseBuilder.AppendLine("HTTP/1.1 200 OK");
                        responseBuilder.AppendLine("Content-Type: application/json");
                        responseBuilder.AppendLine(string.Format("Content-Length: {0}", response.Data.Length));
                        responseBuilder.AppendLine();

                        var headerBytes = Encoding.UTF8.GetBytes(responseBuilder.ToString());

                        stream.Write(headerBytes, 0, headerBytes.Length);
                        int msWaitTime = 10000;
                        Console.WriteLine($"begin sleep: {msWaitTime}");
                        Thread.Sleep(msWaitTime);
                        Console.WriteLine($"end sleep {msWaitTime}");
                        stream.Write(response.Data, 0, response.Data.Length);

                        Debug.WriteLine("Responded");
                        Console.Out.WriteLine("Responded");
                    }
                    else
                    {
                        var responseBuilder = new StringBuilder();
                        responseBuilder.AppendLine("HTTP/1.1 200 OK");
                        responseBuilder.AppendLine("Content-Type: text/html");
                        responseBuilder.AppendLine();
                        responseBuilder.AppendLine("<html><head><title>Test</title></head><body>No Request Processor added</body></html>");
                        responseBuilder.AppendLine("");
                        var responseString = responseBuilder.ToString();
                        var responseBytes = Encoding.UTF8.GetBytes(responseString);

                        stream.Write(responseBytes, 0, responseBytes.Length);
                    }
                }
                catch(Exception ex)
                {
                    Console.Out.WriteLine(ex);
                }
                finally
                {
                    stream.Close();
                    client.Close();
                }
            }
        }
    }
}