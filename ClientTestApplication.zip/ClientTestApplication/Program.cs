﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;
using System.Net.Sockets;
using System.IO;
using System.Threading;

namespace ClientTestApplication
{
    class Program
    {
        static void Main(string[] args)
        {            
            while (true)
            {
                TcpClient tcpClient = null;
                NetworkStream networkStream = null;
                try
                {
                    tcpClient = new TcpClient();
                    int receiveTimeout = tcpClient.ReceiveTimeout;
                    int sendTimeout = tcpClient.SendTimeout;
                    // tcpClient.Connect("10.41.43.133", 64001);
                    // tcpClient.Connect("10.41.43.169", 64001);
                    tcpClient.Connect("10.41.46.10", 64001);
                    // tcpClient.Connect("192.168.99.230", 64001);
                    networkStream = tcpClient.GetStream();

                    byte[] bs1 = Encoding.UTF8.GetBytes("POST /");
                    networkStream.Write(bs1, 0, bs1.Length);
                    byte[] bs2 = new byte[100];
                    int cnt1 = networkStream.Read(bs2, 0, bs2.Length);
                    string response1 = Encoding.UTF8.GetString(bs2, 0, cnt1);
                    Console.Write(response1);
                    Console.WriteLine("unplug cable now");

                    int cnt2 = networkStream.Read(bs2, 0, bs2.Length);
                    string response2 = Encoding.UTF8.GetString(bs2, 0, cnt2);
                    Console.WriteLine(response2);
                    Console.WriteLine($"---- {DateTime.Now}");

                    Thread.Sleep(2000);
                }
                catch(Exception ex)
                {
                    Console.WriteLine(ex);
                }
                finally
                {
                    if (networkStream != null)
                    {
                        networkStream.Close();
                    }
                    if (tcpClient != null)
                    {
                        tcpClient.Close();
                    }
                }
            }
        }
    }
}
